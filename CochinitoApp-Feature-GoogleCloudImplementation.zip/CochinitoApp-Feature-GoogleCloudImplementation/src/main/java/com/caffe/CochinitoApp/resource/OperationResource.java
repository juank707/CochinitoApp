package com.caffe.CochinitoApp.resource;

import lombok.Data;

@Data
public class OperationResource {

    private String consecutive;


    private String value;

    private String transactionDate;

}
