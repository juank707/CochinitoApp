package com.caffe.CochinitoApp.resource;

import lombok.Data;

@Data
public class RoleResource {

    private String name;
}
