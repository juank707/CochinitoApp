package com.caffe.CochinitoApp.core.service;

import com.caffe.CochinitoApp.core.entity.Role;
import com.caffe.CochinitoApp.resource.RoleResource;

public interface RoleService {
    Role createRole(RoleResource resource);

}
