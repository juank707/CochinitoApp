package com.caffe.CochinitoApp.resource;

import lombok.Data;

@Data
public class TransactionResource {

    private String transactionName;
}
